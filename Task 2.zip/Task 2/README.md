# Simple Todo list

A Pen created on CodePen.io. Original URL: [https://codepen.io/rishab0615/pen/oNPNzbM](https://codepen.io/rishab0615/pen/oNPNzbM).

This is  a simple todo list app made by me which is made by using html, CSS and Javascript. It has feature to add, delete and mark-out list items. I have added some basic styling from my side. 